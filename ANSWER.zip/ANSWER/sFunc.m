function output = sFunc(finalB1L1, finalB1L2, finalW1L1, finalW1L2, finalSoftmaxTheta)

[photo,map] = imread('http://eec181.ece.ucdavis.edu:8081/photo.jpg','jpg');

Number_Isolate(photo);

end